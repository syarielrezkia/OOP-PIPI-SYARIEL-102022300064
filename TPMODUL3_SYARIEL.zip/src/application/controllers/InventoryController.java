package application.controllers;

import application.models.Album;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class InventoryController {
    @FXML
    private TableView<Album> albumTable;

    @FXML
    private TableColumn<Album, String> albumNameColumn;

    @FXML
    private TableColumn<Album, String> artistColumn;

    @FXML
    private TableColumn<Album, Integer> totalColumn;

    @FXML
    private TableColumn<Album, Integer> availableColumn;

    @FXML
    private TextField albumNameField;

    @FXML
    private TextField artistField;

    @FXML
    private TextField totalField;

    @FXML
    private TextField availableField;

    @FXML
    private Button addButton;

    private final ObservableList<Album> albumList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        albumNameColumn.setCellValueFactory(new PropertyValueFactory<>("albumName"));
        artistColumn.setCellValueFactory(new PropertyValueFactory<>("artist"));
        totalColumn.setCellValueFactory(new PropertyValueFactory<>("total"));
        availableColumn.setCellValueFactory(new PropertyValueFactory<>("available"));

        albumTable.setItems(albumList);
    }

    @FXML
    void onAdd(ActionEvent event) {
        try {
            String albumName = albumNameField.getText();
            String artist = artistField.getText();
            int total = Integer.parseInt(totalField.getText());
            int available = Integer.parseInt(availableField.getText());

            Album album = new Album(albumName, artist, total, available);
            albumList.add(album);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText("Album Added");
            alert.setContentText("Album " + albumName + " has been added.");
            alert.showAndWait();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Invalid Input");
            alert.setContentText("Please check the input values.");
            alert.showAndWait();
        }
    }
}
