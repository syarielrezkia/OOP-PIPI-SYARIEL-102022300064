module tugas_java {
    requires javafx.controls;
    requires javafx.fxml;

    exports application.controllers;
    opens application.controllers to javafx.fxml;
}
